package com.example.sweethome.alumni;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Sweet Home on 10/11/2016.
 */
public class DatabaseOperations extends SQLiteOpenHelper
{
    public static final int db_version=1;
    public String create_query="CREATE TABLE "+ TableData.TableInfo.Tabname+"("+ TableData.TableInfo.RegNo+" TEXT,"+ TableData.TableInfo.Name+" TEXT,"
            + TableData.TableInfo.Batch+" TEXT,"+ TableData.TableInfo.Department+" TEXT,"+ TableData.TableInfo.Designation+" TEXT,"+ TableData.TableInfo.Password+" TEXT);";
    public DatabaseOperations(Context context)
    {
        super(context, TableData.TableInfo.DBname,null,db_version);
        Log.d("Database Operations","Database Created");
    }
    @Override
    public void onCreate(SQLiteDatabase sdb) {
        sdb.execSQL(create_query);
        Log.d("Database Operations", "Table Created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void putOperations(DatabaseOperations dop,String regno,String name,String batch,String dept,String des,String pass)
    {
        SQLiteDatabase sq=dop.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(TableData.TableInfo.RegNo,regno);
        cv.put(TableData.TableInfo.Name,name);
        cv.put(TableData.TableInfo.Batch,batch);
        cv.put(TableData.TableInfo.Department,dept);
        cv.put(TableData.TableInfo.Designation,des);
        cv.put(TableData.TableInfo.Password, pass);
        Long k=sq.insert(TableData.TableInfo.Tabname,null,cv);
        Log.d("Database Operations", "One Row Inserted");
    }
    public Cursor getInformation(DatabaseOperations dop)
    {
        SQLiteDatabase sq=dop.getReadableDatabase();
        String[] columns={TableData.TableInfo.RegNo, TableData.TableInfo.Name,TableData.TableInfo.Batch,TableData.TableInfo.Department,TableData.TableInfo.Designation, TableData.TableInfo.Password};
        Cursor CR=sq.query(TableData.TableInfo.Tabname,columns,null,null,null,null,null);
        return CR;
    }
}
