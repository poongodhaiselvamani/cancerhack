package com.example.sweethome.alumni;

import android.provider.BaseColumns;

/**
 * Created by Sweet Home on 10/16/2016.
 */
public class TableData1 {
    public TableData1()
    {

    }
    public static abstract class TableInfo1 implements BaseColumns
    {
        public static final String orgname="OrganizerName";
        public static final String eventname="EventName";
        public static final String date="Date";
        public static final String batch="Batch";
        public static final String venue="Venue";
        public static final String DBname="event";
        public static final String Tabname="conduct";
    }
}
