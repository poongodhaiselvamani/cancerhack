package com.example.sweethome.alumni;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by Sweet Home on 10/11/2016.
 */
public class register extends Activity {

    EditText regno,name,batch,dept,des,pass;
    String regno1,name1,batch1,dept1,des1,pass1;
    Button reg;
    Context ctx=this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_layout);
        regno=(EditText)findViewById(R.id.ed1);
        name=(EditText)findViewById(R.id.ed2);
        batch=(EditText)findViewById(R.id.ed3);
        dept=(EditText)findViewById(R.id.ed4);
        des=(EditText)findViewById(R.id.ed5);
        pass=(EditText)findViewById(R.id.ed6);
        reg=(Button)findViewById(R.id.button);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                regno1=regno.getText().toString();
                name1=name.getText().toString();
                batch1=batch.getText().toString();
                dept1=dept.getText().toString();
                des1=des.getText().toString();
                pass1=pass.getText().toString();
                DatabaseOperations DB=new DatabaseOperations(ctx);
                DB.putOperations(DB,regno1,name1,batch1,dept1,des1,pass1);
                Toast.makeText(getBaseContext(),"Your Account has been Created Successfully",Toast.LENGTH_LONG).show();
                finish();
            }
        });
    }
}
