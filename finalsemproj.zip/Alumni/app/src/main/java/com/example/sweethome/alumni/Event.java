package com.example.sweethome.alumni;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by Sweet Home on 10/13/2016.
 */
public class Event extends Activity {
    TextView receive;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_layout);
        receive = (TextView)findViewById(R.id.textView3);
        receive.setText(getIntent().getStringExtra("EdiTtEXTvALUE"));
    }

    public void showconduct(View view) {
        String btn_text;
        btn_text = ((Button) view).getText().toString();
        if (btn_text.equals("Conduct Event")) {
            Intent intent = new Intent(this, Conduct.class);
            startActivity(intent);
        }
    }
}