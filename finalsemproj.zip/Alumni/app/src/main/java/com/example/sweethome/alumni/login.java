package com.example.sweethome.alumni;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by Sweet Home on 10/11/2016.
 */
public class login extends Activity {
    EditText regno,pass,name;
    Button log;
    String regno1,pass1,name1;
    Context CTX=this;
    EditText SendValue;
    Button SendEditTextValue;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);
        SendEditTextValue = (Button)findViewById(R.id.button);
        SendValue = (EditText)findViewById(R.id.ed2);
        regno=(EditText)findViewById(R.id.ed1);
        name=(EditText)findViewById(R.id.ed2);
        pass=(EditText)findViewById(R.id.ed3);
        log=(Button)findViewById(R.id.button2);
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Toast.makeText(getBaseContext(),"please wait..",Toast.LENGTH_LONG).show();
                    regno1=regno.getText().toString();
                    name1=name.getText().toString();
                    pass1=pass.getText().toString();
                    DatabaseOperations dop=new DatabaseOperations(CTX);
                    Cursor CR=dop.getInformation(dop);
                    CR.moveToFirst();
                    boolean loginstatus=false;
                    String NAME="";
                    do {
                        if(regno1.equals(CR.getString(0))&&(pass1.equals(CR.getString(5))))
                        {
                            loginstatus=true;
                            NAME=CR.getString(1);
                        }
                    }while (CR.moveToNext());
                    if(loginstatus)
                    {
                        Toast.makeText(getBaseContext(),"Login Success \n Welcome "+NAME,Toast.LENGTH_LONG).show();
                        intent = new Intent(getApplicationContext(),Event.class);
                        intent.putExtra("EdiTtEXTvALUE", SendValue.getText().toString());
                        startActivity(intent);
                    }
                    else
                    {
                        Toast.makeText(getBaseContext(),"Incorrect Password or Reg.No",Toast.LENGTH_LONG).show();
                    }
                }
        });
    }
    public void showevent(View view) {
        String btn_text;
        btn_text = ((Button) view).getText().toString();
        if (btn_text.equals("Events")) {
            Intent intent = new Intent(this, Event.class);
            startActivity(intent);
        }
    }
}
