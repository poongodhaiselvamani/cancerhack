package com.example.sweethome.alumni;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Sweet Home on 10/13/2016.
 */
public class Conduct extends Activity {
    EditText orgname,eventname,date,batch,venue;
    String orgname1,eventname1,date1,batch1,venue1;
    Button create;
    Context ctx=this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.conduct_layout);
        orgname=(EditText)findViewById(R.id.ed1);
        eventname=(EditText)findViewById(R.id.ed2);
        date=(EditText)findViewById(R.id.ed3);
        batch=(EditText)findViewById(R.id.ed4);
        venue=(EditText)findViewById(R.id.ed5);
        create=(Button)findViewById(R.id.button4);
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                orgname1 = orgname.getText().toString();
                eventname1 = eventname.getText().toString();
                date1 = date.getText().toString();
                batch1 = batch.getText().toString();
                venue1 = venue.getText().toString();
                DatabaseOperations1 DB = new DatabaseOperations1(ctx);
                DB.putOperations(DB, orgname1, eventname1, date1, batch1, venue1);
                Toast.makeText(getBaseContext(), "Event has been Created Successfully", Toast.LENGTH_LONG).show();
                finish();
            }
        });
    }
}
