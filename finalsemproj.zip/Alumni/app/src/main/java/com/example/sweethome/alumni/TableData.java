package com.example.sweethome.alumni;

import android.provider.BaseColumns;

/**
 * Created by Sweet Home on 10/11/2016.
 */
public class TableData  {
    public TableData()
    {

    }
    public static abstract class TableInfo implements BaseColumns
    {
        public static final String RegNo="RegNo";
        public static final String Name="Name";
        public static final String Batch="Batch";
        public static final String Department="Department";
        public static final String Designation="Designation";
        public static final String Password="Password";
        public static final String DBname="Alumni";
        public static final String Tabname="Alum";
    }
}
