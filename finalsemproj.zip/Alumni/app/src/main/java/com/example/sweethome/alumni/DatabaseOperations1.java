package com.example.sweethome.alumni;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Sweet Home on 10/16/2016.
 */
public class DatabaseOperations1 extends SQLiteOpenHelper {
    public static final int db_version=1;
    public String create_query="CREATE TABLE "+ TableData1.TableInfo1.Tabname+"("+ TableData1.TableInfo1.orgname+" TEXT,"+ TableData1.TableInfo1.eventname+" TEXT,"
            + TableData1.TableInfo1.date+" TEXT,"+ TableData1.TableInfo1.batch+" TEXT,"+ TableData1.TableInfo1.venue+" TEXT);";
    public DatabaseOperations1(Context context)
    {
        super(context, TableData1.TableInfo1.DBname,null,db_version);
        Log.d("Database Operations", "Database Created");
    }
    @Override
    public void onCreate(SQLiteDatabase sdb) {
        sdb.execSQL(create_query);
        Log.d("Database Operations", "Table Created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void putOperations(DatabaseOperations1 dop,String orgname,String eventname,String date,String batch,String venue)
    {
        SQLiteDatabase sq=dop.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(TableData1.TableInfo1.orgname,orgname);
        cv.put(TableData1.TableInfo1.eventname,eventname);
        cv.put(TableData1.TableInfo1.date,date);
        cv.put(TableData1.TableInfo1.batch,batch);
        cv.put(TableData1.TableInfo1.venue,venue);
        Long k=sq.insert(TableData1.TableInfo1.Tabname,null,cv);
        Log.d("Database Operations", "One Row Inserted");
    }

}
